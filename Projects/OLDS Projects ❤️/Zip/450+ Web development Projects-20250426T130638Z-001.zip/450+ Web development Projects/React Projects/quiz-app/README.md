Starter code for quiz-app beginner react project

- clone repo
- npm install
- npm start