import Main from "./Main";
import "./index.css";

const App = () => {
  return <Main />;
};

export default App;
