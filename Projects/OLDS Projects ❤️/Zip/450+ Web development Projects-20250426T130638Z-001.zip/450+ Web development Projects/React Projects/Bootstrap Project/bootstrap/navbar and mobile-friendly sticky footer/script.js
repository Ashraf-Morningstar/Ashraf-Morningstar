// fixed navbar and sticky footer for bootstrap
// fixed navbar copied from bootstrap docs