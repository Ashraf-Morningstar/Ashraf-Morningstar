# React-Todo-list

This is a React To do list app developed by me to learn and enhance my react skills.

 
 ## Tech Stack

  `React` `HTML` `CSS` `Javascript`

 ## Learnings

  - React
  - React hooks
  - React props
  - functions
  - State management
  - data processing
  - Error resolving

  ## Screen-shots
![Screenshot 2023-08-11 215157](https://github.com/MaheshRautrao/React-Todo-list/assets/101188065/04005ab9-b684-493e-8898-afd86bbcaca0)
![Screenshot 2023-08-11 215233](https://github.com/MaheshRautrao/React-Todo-list/assets/101188065/a9414999-bcfc-4857-9243-a2734ab3b229)
![Screenshot 2023-08-11 215243](https://github.com/MaheshRautrao/React-Todo-list/assets/101188065/87f07eb1-ad3c-41bf-969f-3aaee0ea645c)
