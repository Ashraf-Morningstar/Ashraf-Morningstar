import Testimonials from "./Testimonials";

function App() {
  return <Testimonials />;
}

export default App;
