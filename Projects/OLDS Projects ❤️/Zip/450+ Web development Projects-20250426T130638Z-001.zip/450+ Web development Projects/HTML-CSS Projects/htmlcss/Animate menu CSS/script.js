// Animate menu mouseover, pure CSS

// inspired: <https://bennettfeely.com>

// Author Joël Lesenne <https://joellesenne.dev>